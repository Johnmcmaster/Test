// Ghidra 11.4.2; VA-mapped raw PE image import with -noanalysis.
// Bounded .pdata unwind ranges, not guaranteed full semantic functions.
// VA 0x1436bc8d0; body [[1436bc8d0, 1436bc9c6]]
// Inferred prototypes/types may be incomplete or incorrect.
// Analysis model: CFG pointer14ADAA220->stub14A59A850 verified; temporary built-in guard_dispatch_icall callfixup; raw exports preserved

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1436bc8d0(longlong param_1)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  
  if (param_1 == 0) {
    FUN_1400bc590();
  }
  else if (_DAT_14cc2b830 <=
           *(int *)(*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)_DAT_14cc17b78 * 8) + 4))
  goto LAB_1436bc903;
  FUN_14a0fe3f0(&DAT_14cc2b830);
  if (_DAT_14cc2b830 == -1) {
    FUN_14038e2e0(0x14cc2b818);
    FUN_14a0fe4b0(&DAT_14cc2b830);
  }
LAB_1436bc903:
  plVar3 = (longlong *)
           (*(longlong *)(param_1 + 0x30) +
           (ulonglong)
           ((int)((ulonglong)(*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) >> 3) -
            1U & _DAT_14cc2b81c) * 8);
  lVar2 = *(longlong *)(param_1 + 0x50);
  do {
    if (*plVar3 == -1) {
      return 0;
    }
    lVar4 = *plVar3 * 0x30;
    plVar3 = (longlong *)(lVar2 + lVar4);
  } while (*(uint *)(lVar2 + 8 + lVar4) != _DAT_14cc2b81c);
  lVar2 = lVar2 + lVar4;
  if (*(longlong *)(param_1 + 0x58) == lVar2) {
    uVar1 = 0;
  }
  else {
    uVar1 = 0;
    if (*(int *)(lVar2 + 0x28) == -0x243f43f) {
      uVar1 = *(undefined8 *)(lVar2 + 0x10);
    }
    if (*(char *)(lVar2 + 0x2c) == '\x04') {
      uVar1 = 0;
    }
  }
  return uVar1;
}


