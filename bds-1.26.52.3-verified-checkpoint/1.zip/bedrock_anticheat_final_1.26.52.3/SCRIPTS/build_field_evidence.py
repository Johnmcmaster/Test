#!/usr/bin/env python3
"""Export actual memory operands for manually delimited component/register bindings.

Bindings are scoped to exact instruction windows, not inferred from matching an
offset alone. Opaque header padding is not a recovered field. Composite SSE
accesses retain their actual width; e.g. a16byte clear covers two qwords.
"""
import argparse,csv,hashlib,json
from pathlib import Path
from capstone.x86 import X86_OP_MEM
from research import Image
ap=argparse.ArgumentParser();ap.add_argument('exe',type=Path);ap.add_argument('root',type=Path);a=ap.parse_args()
assert hashlib.file_digest(a.exe.open('rb'),'sha256').hexdigest()=='19c88569af2e4b7d984e999055a31cbcb0799dacf8bbbf7371eda42f5772a443'
im=Image(a.exe,a.root/'DATA')
# type, function, window-start, window-end-inclusive, component-base, layout-limit, proof.
B=[
('StateVectorComponent',0x148265630,0x148265693,0x1482656d7,'r15',0x24,'Six-component view supplies StateVector as sixth argument; saved inR15 at5661.'),
('AABBShapeComponent',0x148265630,0x148265697,0x1482656be,'r14',0x20,'View supplies AABB fifth argument, saved inR14; XYZ derivation reads its endpoints.'),
('OffsetsComponent',0x148265630,0x148265693,0x148265693,'rbx',0x44,'R8 optional offset pointer saved inRBX at5673.'),
('ActorSetPositionRequestComponent',0x145e33650,0x145e33728,0x145e3372e,'rax',12,'RAX is typed storage lookup/ensure result; qwordXY andDWORDZ stores.'),
('DepenetrationComponent',0x145e38860,0x145e38860,0x145e388c3,'rdx',0x38,'Second argument, verified predecessor component access; explicit bounded leaf.'),
('MoveRequestComponent',0x145e38860,0x145e388c8,0x145e388d4,'r8',0x98,'Third argument receives threshold vector used by contact/path response.'),
('ApplyGravityComponent',0x141c867b0,0x141c867b0,0x141c867cd,'rdx',8,'Second argument, ID48C5D5FE pool supplied by enclosing view.'),
('StateVectorComponent',0x141c867b0,0x141c867b0,0x141c867cd,'r8',0x24,'Third argument receives scalar vertical addition.'),
('FallDistanceComponent',0x141c867b0,0x141c867b0,0x141c867cd,'r9',4,'Fourth argument fromCE6B34F6 pool; independent type-name initializer audited.'),
('ApplyGravityComponent',0x141c5c910,0x141c5ca26,0x141c5ca41,'rax',8,'Typed pool lookup/ensure result at tail; exact stores scalar0/byte4.'),
('BounceGravityCorrectionComponent',0x141c853c0,0x141c853e0,0x141c85415,'r8',8,'Third argument; verified7F176DF4 view dependency.'),
('ApplyGravityComponent',0x141c853c0,0x141c853e0,0x141c854df,'rdx',8,'Second argument remains gravity component across saved/restored import call.'),
('StateVectorComponent',0x141c853c0,0x141c854b7,0x141c854c5,'r9',0x24,'Fourth argument, scalar bounce response writes vertical motion.'),
('MobTravelComponent',0x148456490,0x1484566ac,0x1484566ac,'rdi',0x28,'Native sixth argument fromMobTravel view saved inRDI.'),
('MobTravelComponent',0x1484454b0,0x1484457b3,0x1484457b3,'rax',0x28,'Explicit39CF8D64 pool lookup/ensure result, outputscalar0C.'),
('ServerPlayerCurrentMovementComponent',0x1411750c0,0x141175336,0x1411753a9,'r9',0x108,'Fourth argument is reported movement payload; R9 preserved until this window ends.'),
('StateVectorComponent',0x1411750c0,0x141175336,0x141175354,'r14',0x24,'Typed1B5D5238 pool/sparse lookup at51137..5221D bindsR14.'),
('ServerPlayerMovementComponent',0x14116ec10,0x14116ec51,0x14116eddf,'rdi',0x48,'Component pointer saved fromRCX; pending deque fields.'),
('ReplayStorageAllocation',0x146625230,0x1466252f0,0x146625304,'r14',0x60,'Second allocation0x60 saved inR14.'),
('ReplayStorageAllocation',0x146625230,0x146625344,0x146625361,'rcx',0x60,'Reloads the same storage pointer at5331; proxy/baseTick/vector clears.'),
('ReplayStateComponent',0x146625230,0x146625365,0x146625377,'rsi',0x20,'Returned component destination fromfirst argument.'),
('ReplayStateTrackerComponent',0x145e64e60,0x145e64ebc,0x145e65024,'rsi',0x68,'Tracker argumentRDX saved inRSI at4E73; value/dirty accesses.'),
('FrictionModifierOverrideComponent',0x142c19020,0x142c19177,0x142c191a9,'r15',4,'Indexed component payload pointerR15 plusR14*4, after0CBB7191 lookup.'),
]
rows=[]
for component,va,start,end,reg,limit,proof in B:
 paths=list((a.root/'ASSEMBLY').rglob(f'{va:016X}.asm'))+list((a.root/'BASELINE/DECOMPILATION').rglob(f'{va:016X}.asm'))
 if not paths:raise SystemExit(f'MissingASM{va:x}')
 source=paths[0];header=source.read_text().splitlines()[0];import re
 stop=int(re.search(r'end=(0x[0-9a-f]+)',header,re.I)[1],16)
 for i in im.md.disasm(im.pe.read_va(va,stop-va),va):
  if not start<=i.address<=end:continue
  for n,o in enumerate(i.operands):
   if o.type!=X86_OP_MEM or i.reg_name(o.mem.base)!=reg or not 0<=o.mem.disp<limit:continue
   access=','.join(x for bit,x in [(1,'read'),(2,'write')]if o.access&bit)or'address/unknown'
   rows.append({'component_or_allocation':component,'offset':hex(o.mem.disp),'width_bytes':o.size,'access':access,'function_va':hex(va),'instruction_va':hex(i.address),'base_register':reg,'index_register':i.reg_name(o.mem.index)if o.mem.index else'','index_scale':o.mem.scale,'instruction':i.mnemonic+' '+i.op_str,'source_artifact':str(source.relative_to(a.root)),'binding_evidence':proof,'confidence':'confirmed bounded access; semantic names limited to report'})
out=a.root/'DATA/COMPONENT_FIELD_EVIDENCE.csv'
with out.open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({'rows':len(rows),'binding_windows':len(B),'output':str(out)}))
