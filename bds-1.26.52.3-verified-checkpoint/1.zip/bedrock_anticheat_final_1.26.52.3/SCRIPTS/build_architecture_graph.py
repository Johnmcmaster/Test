#!/usr/bin/env python3
"""Build the curated graph. This is not a whole-program call graph.

Direct edges are checked against the saved Capstone assembly. Other edge kinds
have explicit provenance and never imply a guaranteed scheduler phase order.
"""
import csv
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
NODES = {}
EDGES = []


def node(key, label, kind="function"):
    NODES[key] = (label, kind)


def function(va, label):
    key = "f" + va.lower().removeprefix("0x")
    node(key, label + "\n0x" + va.upper().removeprefix("0X"))
    return key


def edge(source, target, kind, label, evidence, confidence="confirmed", site=""):
    assert source in NODES and target in NODES
    EDGES.append(dict(source=source, target=target, kind=kind, label=label,
                      confidence=confidence, instruction_va=site,
                      source_artifact=evidence))


def assembly(va):
    candidates = sorted((ROOT / "ASSEMBLY").rglob("*" + va.upper().removeprefix("0X") + ".asm"))
    if not candidates:
        raise RuntimeError("Missing assembly for " + va)
    return candidates[0]


def call(source, target, label="direct call"):
    va = source[1:]
    target_va = target[1:]
    artifact = assembly(va)
    pattern = re.compile(r"^([0-9a-f]+):.*\bcall\s+0x0*" + target_va + r"\b", re.I | re.M)
    matches = pattern.findall(artifact.read_text())
    if not matches:
        raise RuntimeError("Direct call not in saved assembly: " + source + " -> " + target)
    edge(source, target, "direct_call", label, str(artifact.relative_to(ROOT)),
         site=";".join("0x" + m.upper().lstrip("0") for m in matches))


input_handler = function("1409A5710", "Server packet input handler")
input_validation = function("1432F8DB0", "Packet payload validation")
input_ingress = function("14116F050", "Move input ingress")
input_append = function("14116EE60", "Pending-record insertion")
input_select = function("14116EC10", "Pending-record selector")
input_consume = function("1457BA650", "Pending-record copy/pop")
input_drain1 = function("1457BB0A0", "Input-related drain helper")
input_drain2 = function("1457BB5C0", "Input-related iteration helper")
node("pending_queue", "ServerPlayerMovementComponent\n0x48-byte payload / 0x168-byte records", "storage")
call(input_handler, input_ingress)
call(input_ingress, input_append)
call(input_handler, input_drain1, "conditional call")
call(input_handler, input_drain2, "conditional call")
edge(input_handler, input_validation, "resolved_indirect", "packet vtable+0x58", "DECOMPILATION/ghidra_cfg/input02/0x1409a5710_FUN_1409a5710.c; FINAL_RESEARCH_REPORT.md", site="0x1409A575A")
edge(input_append, "pending_queue", "data_flow", "append input records", "FINAL_RESEARCH_REPORT.md")
edge("pending_queue", input_select, "data_flow", "select pending record", "FINAL_RESEARCH_REPORT.md")
edge("pending_queue", input_consume, "data_flow", "consume and remove records", "FINAL_RESEARCH_REPORT.md")

pred_system = function("143B570F0", "PredictedMovement bulk method")
pred_iter = function("143B56B70", "PredictedMovement iterator callback")
pred_callback = function("143B4C860", "Timestamped sample callback")
sample_create = function("141165620", "Shared sample construction / enqueue")
sample_process = function("141166420", "Timestamp bracketing / interpolation")
position_bridge = function("140D3E290", "Interpolator target / position fallback")
node("sample_queue", "PredictedMovement+0x30\nshared timestamped samples", "storage")
call(pred_system, pred_iter)
edge(pred_system, pred_callback, "registration", "local callback-cell initialization", "ASSEMBLY/0000000143B570F0.asm", site="0x143B5755D;0x143B57564")
edge(pred_iter, pred_callback, "resolved_indirect", "CFG target loaded from callback cell", "ASSEMBLY/0000000143B56B70.asm; DATA/cfg_dispatch_proof.json", site="0x143B56C98;0x143B56C9C;0x143B56D32")
call(pred_callback, sample_create)
call(pred_callback, sample_process)
call(sample_process, position_bridge)
edge(sample_create, "sample_queue", "data_flow", "dynamic shared-sample queue insertion", "WORK/predicted/evidence.csv", site="0x14116579B;0x1411657D0")
edge("sample_queue", sample_process, "data_flow", "time bracketing and wrapped-angle interpolation", "WORK/predicted/evidence.csv", site="0x1411666D7;0x141166D1D")

collision_tick = function("142F2FCB0", "MoveCollisionSystem bulk method")
collision_entity = function("142F310A0", "Collision candidate query wrapper")
collision_query = function("142F191B0", "Vector cap / swept bounds / candidate acquisition")
contact = function("142F77210", "One-candidate AABB response")
path = function("1424E1840", "Reverse candidate traversal / path response")
step_tick = function("145E59030", "AutoStepSystem bulk method")
step_iter = function("145E58EF0", "Auto-step iterator callback")
step = function("145E587B0", "Numerical auto-step trial")
step_tag = function("145E58350", "Ensure auto-step marker storage")
node("shape_receiver", "Concrete world-shape query receiver\nvirtual+0xB0 target unresolved", "unknown")
node("candidate_aabbs", "Candidate AABB vector\nMoveRequest+0x58", "storage")
node("move_request", "MoveRequestComponent\nselected vector+0x3C / bounds", "storage")
call(collision_tick, collision_entity)
call(collision_entity, collision_query)
edge(collision_query, "shape_receiver", "unresolved", "virtual+0xB0 / concrete receiver missing", "ASSEMBLY/0000000142F191B0.asm", confidence="unresolved", site="0x142F1971B;0x142F19739")
edge(collision_query, "candidate_aabbs", "data_flow", "candidate collection / cache writes", "DECOMPILATION/ghidra/primary/0x142f191b0_FUN_142f191b0.c", confidence="strongly supported")
call(step_tick, step_iter)
edge(step_iter, step, "resolved_indirect", "captured auto-step callback through CFG", "DECOMPILATION/ghidra/collision02/0x145e58ef0_FUN_145e58ef0.c; ASSEMBLY/collision/0000000145E59030.asm", site="0x145E58FA1")
call(step, path, "up/X/Z trial then downward trial")
call(path, contact, "reverse candidate loop")
call(step, step_tag, "successful-trial branch")
edge("candidate_aabbs", step, "data_flow", "filtered trial list + original overlap checks", "DECOMPILATION/typed_collision/0x145e587b0_FUN_145e587b0.c")
edge("candidate_aabbs", path, "data_flow", "caller-provided AABB list", "DECOMPILATION/typed_collision/0x1424e1840_FUN_1424e1840.c")
edge(step, "move_request", "data_flow", "adopt improved horizontal result only", "ASSEMBLY/0000000145E587B0.asm", site="0x145E58B56;0x145E58C5B")

filter_ctor = function("148267D70", "NoClipOrNoBlock named system construction")
filter_tick = function("14826DE30", "Named filter bulk method")
filter_entity = function("14826F150", "Named filter entity method")
filter_body = function("148265630", "Move/bounds application or alternate world branch")
translate_bounds = function("142535850", "Translate AABB and sub-bounds")
node("filter_table", "NoClipOrNoBlockMoveFilterSystem\ntable 0x14A9254B0", "descriptor")
node("state_position", "StateVectorComponent\nposition +0x00/+0x04/+0x08", "storage")
node("filter_world_callback", "Alternate block-source callback\nconcrete target unresolved", "unknown")
edge(filter_ctor, "filter_table", "registration", "same descriptor: vptr + SSE name copy", "ASSEMBLY/0000000148267D70.asm", site="0x148268C4E;0x148268C55;0x148268CB7;0x148268CC2")
edge("filter_table", filter_tick, "registration", "method slot+0x28", "WORK/physics/no_clip_table.json")
edge("filter_table", filter_entity, "registration", "method slot+0x30", "WORK/physics/no_clip_table.json")
call(filter_entity, filter_body)
call(filter_body, translate_bounds, "ActorDataFlag+6 bit0-clear branch")
edge("move_request", filter_body, "data_flow", "vector+0x3C is application input", "ASSEMBLY/0000000148265630.asm")
edge(filter_body, "state_position", "data_flow", "write box-center X/Z and lower-Y+offset", "ASSEMBLY/0000000148265630.asm", site="0x1482656CC;0x1482656D1;0x1482656D7")
edge(filter_body, "filter_world_callback", "unresolved", "alternate flag branch; no cheat verdict established", "ASSEMBLY/0000000148265630.asm", confidence="unresolved", site="0x1482658B7")

request_setter = function("145E33650", "Position-request setter")
request_single = function("145E32BD0", "Single-entity ActorSetPosSystem")
request_bulk = function("145E2F7E0", "Bulk ActorSetPosSystem")
request_apply = function("145E2ED50", "Requested XYZ application / bounds updates")
node("position_request", "ActorSetPositionRequestComponent\n12-byte XYZ payload", "storage")
edge(position_bridge, request_setter, "direct_call", "fallback direct call", "ASSEMBLY/predicted/0000000140D3E290.asm", site="0x140D3E414")
call(sample_process, request_setter, "optional sample-position branch")
edge(request_setter, "position_request", "data_flow", "write request XYZ", "BASELINE/POSITION_REQUEST_LIFECYCLE.md")
edge(request_setter, request_single, "direct_call", "synchronous call; baseline verified", "BASELINE/POSITION_REQUEST_LIFECYCLE.md", site="0x145E33769")
edge(request_single, request_apply, "direct_call", "eligible intersection; baseline verified", "BASELINE/POSITION_REQUEST_LIFECYCLE.md", site="0x145E32FE0")
edge(request_bulk, request_apply, "direct_call", "bulk intersection; baseline verified", "BASELINE/EVIDENCE.csv", site="0x145E30788")
edge("position_request", request_apply, "data_flow", "request is separate from StateVector", "BASELINE/POSITION_REQUEST_LIFECYCLE.md")
edge(request_apply, "state_position", "data_flow", "copy XYZ before synchronous setter returns", "BASELINE/POSITION_REQUEST_LIFECYCLE.md")

glide_tick = function("148440B70", "GlideMoveSystem bulk method")
glide_iter = function("148440A20", "Glide iterator callback wrapper")
glide_entity = function("148441A90", "GlideMoveSystem entity method")
glide = function("1484403B0", "Glide numerical recurrence")
accel = function("14845B3C0", "WaterMove three-axis acceleration + yaw rotation")
water_move_iter = function("14845B4E0", "WaterMove captured callback wrapper")
water_tick = function("14845ED50", "WaterTravel bulk wrapper")
water_iter = function("14845E860", "WaterTravel callback wrapper")
water_coefficient = function("148456490", "WaterTravel coefficient selection")
node("physics_modes", "Full player mode/mechanics dispatch\nwalking, flight, effects etc unresolved", "unknown")
node("state_motion", "StateVector tail\n+0x18/+0x1C/+0x20", "storage")
call(glide_tick, glide_iter)
call(glide_entity, glide)
edge(glide_iter, glide, "resolved_indirect", "captured glide callback through CFG", "DECOMPILATION/ghidra_cfg/physics01/0x148440a20_FUN_148440a20.c; ASSEMBLY/0000000148440A20.asm", site="0x148440AE5")
call(water_tick, water_iter)
edge(water_iter, water_coefficient, "resolved_indirect", "WaterTravel callback supplied by owner", "DECOMPILATION/ghidra_cfg/physics01/0x14845e860_FUN_14845e860.c; DECOMPILATION/ghidra_cfg/physics01/0x14845ed50_FUN_14845ed50.c")
edge(glide, "state_motion", "data_flow", "velocity recurrence / selected gravity dependency", "DECOMPILATION/ghidra/physics01/0x1484403b0_FUN_1484403b0.c")
edge(accel, "state_motion", "data_flow", "add input acceleration using caller scalar/trig", "ASSEMBLY/000000014845B3C0.asm")
edge(water_move_iter, accel, "resolved_indirect", "named WaterMoveSystem table+0x28 route", "WORK/walking_flight/registration_contexts.txt; WORK/walking_flight/next_callbacks.py; ASSEMBLY/000000014845B3C0.asm", confidence="strongly supported")
edge("physics_modes", glide, "unresolved", "full eligibility/caller mechanics unresolved", "UNRESOLVED.md", confidence="unresolved")
edge("physics_modes", accel, "unresolved", "complete mode-specific coefficient path unresolved", "UNRESOLVED.md", confidence="unresolved")

ground_tick1 = function("148447E50", "GroundTravelType conditional route A")
ground_tick2 = function("1484469F0", "GroundTravelType conditional route B")
ground_coefficient1 = function("148447B00", "Ground/block-dependent acceleration coefficient A")
ground_coefficient2 = function("1484454B0", "Ground/block-dependent acceleration coefficient B")
vertical_fly_tick = function("142C47700", "VerticalFlySpeedControl bulk method")
vertical_fly = function("142C19020", "Ported vertical-fly numerical callback")
lava_tick = function("14842BC20", "LavaMove bulk method")
lava = function("14842B540", "LavaMove callback")
levitate_tick = function("141C87D40", "LevitateSystem bulk method")
levitate = function("141C5EB90", "Ported levitation numerical callback")
levitate_entity = function("141C88390", "Levitate entity method")
edge(ground_tick1, ground_coefficient1, "resolved_indirect", "captured callback initialized here", "ASSEMBLY/walking_flight/0000000148447E50.asm", site="0x148447F92")
edge(ground_tick2, ground_coefficient2, "resolved_indirect", "captured callback initialized here", "ASSEMBLY/walking_flight/00000001484469F0.asm", site="0x148446B32")
edge(vertical_fly_tick, vertical_fly, "resolved_indirect", "captured callback initialized here", "ASSEMBLY/walking_flight/0000000142C47700.asm", site="0x142C477D1")
edge(lava_tick, lava, "resolved_indirect", "captured callback initialized here", "ASSEMBLY/walking_flight/000000014842BC20.asm", site="0x14842BCC9")
edge(levitate_tick, levitate, "resolved_indirect", "callback141C87BE0 tail-jumps to body", "ASSEMBLY/walking_flight/0000000141C87D40.asm; WORK/walking_flight/next_callbacks.py", site="0x141C87DAA")
call(levitate_entity, levitate)
edge(vertical_fly, "state_motion", "data_flow", "vertical tail field+0x1C update", "DECOMPILATION/ghidra/root_ground_fly/0x142c19020_FUN_142c19020.c")
edge(levitate, "state_motion", "data_flow", "guarded effect-record vertical recurrence", "ASSEMBLY/walking_flight/0000000141C5EB90.asm; JAVA/physics-kernels/levitation_machine_validation.json")
edge(lava, "state_motion", "data_flow", "mode-local numerical behavior; not complete lava mechanics", "DECOMPILATION/ghidra/root_ground_fly/0x14842b540_FUN_14842b540.c", confidence="strongly supported")

correction_tick = function("1457D5D20", "Movement correction system")
correction_view = function("1457D4BC0", "Four-component iteration")
correction_iter = function("1457D5B70", "Reconciliation entity trampoline")
reconcile = function("1457D54A0", "Movement reconciliation")
residual = function("1411750C0", "Concrete residual selector")
node("correction_packet", "CorrectPlayerMovePredictionPacket\ntable 0x14A7F36A0 / ID 0xA1", "packet")
node("sender", "Sender virtual+0x30\nconcrete transport target unresolved", "unknown")
node("reported_position", "Client-reported current movement\nXYZ+0x38", "storage")
edge(correction_tick, correction_view, "direct_call", "baseline verified chain", "BASELINE/MOVEMENT_ARCHITECTURE.md")
edge(correction_view, correction_iter, "direct_call", "baseline verified chain", "BASELINE/MOVEMENT_ARCHITECTURE.md")
edge(correction_iter, reconcile, "direct_call", "baseline verified chain", "BASELINE/MOVEMENT_ARCHITECTURE.md")
edge(reconcile, residual, "resolved_indirect", "ReplayState+0x10 / vtable+0x10 through CFG", "ASSEMBLY/input/00000001457D54A0.asm; DECOMPILATION/input/residual_selector_1411750C0.cpp", site="0x1457D573C")
edge("state_position", residual, "data_flow", "independent reference position", "DECOMPILATION/input/residual_selector_1411750C0.cpp")
edge("reported_position", residual, "data_flow", "reported position and rotation residual", "DECOMPILATION/input/residual_selector_1411750C0.cpp")
edge(reconcile, "state_motion", "data_flow", "tag1: add accepted-target residual; XYZ untouched", "ASSEMBLY/input/00000001457D54A0.asm", site="0x1457D5A1A;0x1457D5A4A")
edge(reconcile, "correction_packet", "data_flow", "tag2 player branch copies authoritative fields", "ASSEMBLY/input/00000001457D54A0.asm")
edge("correction_packet", "sender", "unresolved", "queue/send via virtual+0x30", "ASSEMBLY/input/00000001457D54A0.asm", confidence="unresolved", site="0x1457D5A0F")
call(reconcile, request_setter, "separate position-request branch")

replay_wrapper = function("14469C820", "EntitySystems replay-category wrapper")
dispatcher = function("1425705D0", "Ordered synchronous category dispatcher")
register_three = function("141924800", "Three-token registration helper")
register_four = function("14469CCD0", "Four-token registration helper")
register_wrapper = function("1418E5730", "Registration wrapper")
node("replay_category", "Replay category token\nbacking global 0x14CCB1044", "descriptor")
node("category_systems", "Category DWORD system-ID vector\nordered traversal; membership varies", "descriptor")
node("tick_connection", "Input → physics → reconciliation → flush\nwhole-tick phase order unresolved", "unknown")
call(register_wrapper, register_three)
edge(register_three, "category_systems", "registration", "span3: FB4/FBC/FC4; no local replay token", "ASSEMBLY/0000000141924800.asm")
edge(register_four, "replay_category", "registration", "span4 includes replay token", "ECS_EXECUTION_ORDER.md")
edge(replay_wrapper, "replay_category", "registration", "selects token for a category pass", "MOVEMENT_REPLAY.md; BASELINE/EVIDENCE.csv")
edge("replay_category", dispatcher, "resolved_indirect", "dispatcher route; not a full restore loop", "MOVEMENT_REPLAY.md; ECS_EXECUTION_ORDER.md", confidence="strongly supported")
edge(dispatcher, "category_systems", "data_flow", "synchronous list traversal in stored order", "ECS_EXECUTION_ORDER.md")
edge("tick_connection", collision_tick, "unresolved", "exact server-player phase edge missing", "ECS_EXECUTION_ORDER.md", confidence="unresolved")
edge("tick_connection", correction_tick, "unresolved", "exact server-player phase edge missing", "ECS_EXECUTION_ORDER.md", confidence="unresolved")
edge("tick_connection", replay_wrapper, "unresolved", "outer replay scheduling/termination missing", "MOVEMENT_REPLAY.md", confidence="unresolved")

history_factory = function("146625230", "Replay callback + optional 0x60 storage factory")
history_reader = function("14839F2A0", "Unsigned tick-indexed snapshot lookup")
history_float = function("1483A7A60", "Related retained snapshot consumer")
history_effect = function("142EAB580", "Effect/history callback path")
history_lend = function("146619C30", "Clear/transfer ReplayState to vehicle")
node("retained_storage", "ReplayState+8 optional storage\ndeque map / front / count / base tick", "storage")
node("snapshot_writer", "Retained-record producer + concrete snapshot table\nunresolved", "unknown")
node("snapshot_virtual88", "record+0x38 snapshot interface\nvirtual+0x88 implementation unresolved", "unknown")
edge(history_factory, "retained_storage", "data_flow", "allocate and initialize; capacity1..1000", "DECOMPILATION/baseline/0x146625230_FUN_146625230.c")
edge(history_lend, "retained_storage", "data_flow", "clear deque/vector fields before ownership transfer", "ASSEMBLY/history/replay_candidates/0000000146619C30.asm")
edge("snapshot_writer", "retained_storage", "unresolved", "append/retention policy not recovered", "MOVEMENT_HISTORY.md", confidence="unresolved")
edge("retained_storage", history_reader, "data_flow", "tick-base index / count / masked map lookup", "ASSEMBLY/000000014839F2A0.asm")
edge("retained_storage", history_float, "data_flow", "optional retained-record interface path", "DECOMPILATION/ghidra_cfg/collision03/0x1483a7a60_FUN_1483a7a60.c")
edge("retained_storage", history_effect, "data_flow", "optional snapshot virtual+0x58 path", "DECOMPILATION/ghidra_cfg/collision03/0x142eab580_FUN_142eab580.c")
edge(history_reader, "snapshot_virtual88", "unresolved", "CFG-mediated tail jump; concrete restore not recovered", "ASSEMBLY/000000014839F2A0.asm", confidence="unresolved", site="0x14839F2F2")

tracker_update = function("145E64E60", "Metadata value / dirty-mask update")
tracker_update2 = function("145E65EA0", "Metadata alternate current-value update")
tracker_gather = function("145E65390", "ActorDataFlag + four optional handles")
tracker_capture = function("145E5C6D0", "Metadata mask/value capture")
node("metadata_tracker", "ReplayStateTrackerComponent\n0x68 bytes; no list of player XYZ", "storage")
call(tracker_update, tracker_gather)
call(tracker_update, tracker_capture)
call(tracker_update2, tracker_gather)
call(tracker_update2, tracker_capture)
edge(tracker_update, "metadata_tracker", "data_flow", "current values + XOR/boolean change indicators", "ASSEMBLY/0000000145E64E60.asm")
edge(tracker_update2, "metadata_tracker", "data_flow", "alternate current-value route", "ASSEMBLY/0000000145E65EA0.asm")

gravity_prepare=function('141C5C910','Gravity request generator')
gravity_apply=function('141C867B0','Gravity scalar application')
gravity_bounce=function('141C853C0','Bounce correction / consume request')
vertical_drag=function('141C6A570','Ground/air vertical drag')
flying_drag=function('141C6D8F0','Player-flying vertical drag')
ground_coefficient=function('1484454B0','Ground coefficient: block field')
ground_coefficient2=function('148447B00','Ground coefficient: material field')
depenetration_threshold=function('145E38860','Depenetration threshold leaf')
node('gravity_component','ApplyGravityComponent\nscalar+0 / byte+4','storage')
node('move_control_receiver','MoveControlComponent+0x20 object\nvirtual+0x10 target unresolved','unknown')
control=function('142F1B480','MoveControl gates / callback')
edge(gravity_prepare,'gravity_component','data_flow','conditional scalar/byte write','ASSEMBLY/0000000141C5C910.asm; DATA/GRAVITY_TYPE_BINDING.json')
edge('gravity_component',gravity_apply,'data_flow','scalar addition to StateVectorY','ASSEMBLY/0000000141C867B0.asm')
edge('gravity_component',gravity_bounce,'data_flow','alternative correction/erase route','ASSEMBLY/0000000141C853C0.asm')
edge(gravity_apply,'state_motion','data_flow','Y += scalar','ASSEMBLY/0000000141C867B0.asm')
edge(gravity_bounce,'state_motion','data_flow','sqrt-based scalar correction','ASSEMBLY/0000000141C853C0.asm')
edge(vertical_drag,'state_motion','data_flow','vertical drag only','ASSEMBLY/0000000141C6A570.asm')
edge(flying_drag,'state_motion','data_flow','vertical drag / separate scalar clear','ASSEMBLY/0000000141C6D8F0.asm')
node('mob_travel_scalar','MobTravelComponent+0xC\nacceleration coefficient','storage')
edge(ground_coefficient,'mob_travel_scalar','data_flow','block-derived inverse-cube coefficient','JAVA/physics-kernels/ground_machine_validation.json')
edge(ground_coefficient2,'mob_travel_scalar','data_flow','material-derived inverse-cube coefficient','JAVA/physics-kernels/ground_machine_validation.json')
edge(depenetration_threshold,'move_request','data_flow','threshold fields+0x48/4C/50','ASSEMBLY/0000000145E38860.asm')
edge(control,'move_control_receiver','unresolved','CFG tail dispatch after actor gates','ASSEMBLY/0000000142F1B480.asm',confidence='unresolved',site='0x142F1B4DC')

def main():
    output = ROOT / "DATA" / "CALL_GRAPH_EDGES.csv"
    with output.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(EDGES[0]))
        writer.writeheader()
        writer.writerows(EDGES)
    style = {
        "direct_call": 'color="#252525",style=solid',
        "resolved_indirect": 'color="#087f3e",style=bold',
        "registration": 'color="#7047a8",style=dashed,arrowhead=vee',
        "data_flow": 'color="#1765a0",style=dotted',
        "unresolved": 'color="#bd2929",style=dashed',
    }
    lines = [
        'digraph BedrockMovement {',
        '  graph [rankdir=LR, overlap=false, compound=true, fontname="Helvetica", labelloc=t,',
        '    label="BDS 1.26.52.3 — curated static calls and dependencies\\nNo universal whole-tick scheduler ordering is asserted"];',
        '  node [shape=box, fontname="Helvetica", fontsize=10];',
        '  edge [fontname="Helvetica", fontsize=8];',
        '  legend [shape=note,label="Black solid: direct native call\\nGreen bold: statically resolved indirect/callback route\\nPurple dashed: table/registration metadata (not execution order)\\nBlue dotted: data dependency (not execution order)\\nRed dashed: unresolved edge/target\\nExact provenance: DATA/CALL_GRAPH_EDGES.csv"];',
    ]
    kinds = {
        "function": '',
        "storage": ',shape=cylinder,color="#1765a0"',
        "descriptor": ',shape=component,color="#7047a8"',
        "packet": ',shape=box3d,color="#1765a0"',
        "unknown": ',shape=octagon,color="#bd2929",style=dashed',
    }
    for key, (label, kind) in NODES.items():
        lines.append(f"  {key} [label={json.dumps(label)}{kinds[kind]}];")
    for item in EDGES:
        label = item["label"]
        if item["instruction_va"]:
            label += "\n" + item["instruction_va"].split(";")[0]
        lines.append(f'  {item["source"]} -> {item["target"]} [label={json.dumps(label)}, {style[item["kind"]]}];')
    lines.append("}")
    (ROOT / "CALL_GRAPH.dot").write_text("\n".join(lines) + "\n")
    print(f"Wrote {len(NODES)} nodes, {len(EDGES)} curated edges")


if __name__ == "__main__":
    main()
