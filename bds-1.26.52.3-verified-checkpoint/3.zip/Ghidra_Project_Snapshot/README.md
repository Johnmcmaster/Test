# Full Ghidra project snapshot

Optional ZIPs3 through14 contain the exact current closed project. Each ZIP is independently extractable. Extract all into the same folder; then run `python Ghidra_Project_Snapshot/RESTORE.py` (Python3.12+). It joins the fragments, verifies SHA256, safely extracts and verifies every project file. Open RESTORED/PositionPart6Raw.gpr in Ghidra11.4.2 with Java21.

This raw database includes imported machine code. It is not original Mojang source and is not a whole-program decompilation. The original server executable and standalone mapped input file are not bundled. Targeted raw/CFG/typed C exports and all research/scripts are in research ZIPs1-2.
