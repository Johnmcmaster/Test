#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,lzma,tarfile
r=Path(__file__).resolve().parent;m=json.loads((r/'MANIFEST.json').read_text());out=r/'project.tar.xz'
with out.open('wb')as f:
 for p in m['parts']:
  data=(r/p['name']).read_bytes();assert len(data)==p['bytes']and hashlib.sha256(data).hexdigest()==p['sha256'],p['name'];f.write(data)
assert hashlib.file_digest(out.open('rb'),'sha256').hexdigest()==m['stream_sha256']
dest=r/'RESTORED';dest.mkdir(exist_ok=True)
with tarfile.open(out,'r:xz')as t:t.extractall(dest,filter='data')
for name,expected in m['files_sha256'].items():
 assert hashlib.file_digest((dest/name).open('rb'),'sha256').hexdigest()==expected,name
print('Verified complete project:',dest/(m['project']+'.gpr'))
